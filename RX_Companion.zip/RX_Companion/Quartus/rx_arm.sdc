# FPGA_CLK1_50: 50 MHz oscillator, 20 ns period
create_clock -name FPGA_CLK1_50 -period 20.000 [get_ports {FPGA_CLK1_50}]

derive_clock_uncertainty