// Receiver top level. Clock input must be 50 MHz.
// RESET_N is an active-low external reset, assigned to a board key later.
// SERVO_PWM[0..5]: base, shoulder, elbow, pitch, roll, claw.
// Board pin assignments and timing constraints must be added before fitting.
`default_nettype none
module rx_arm (
    input wire FPGA_CLK1_50,
    input wire RESET_N,
    output wire [5:0] SERVO_PWM,
    output wire  hps_io_hps_io_emac1_inst_TX_CLK,
    output wire  hps_io_hps_io_emac1_inst_TXD0,
    output wire  hps_io_hps_io_emac1_inst_TXD1,
    output wire  hps_io_hps_io_emac1_inst_TXD2,
    output wire  hps_io_hps_io_emac1_inst_TXD3,
    input wire  hps_io_hps_io_emac1_inst_RXD0,
    inout wire  hps_io_hps_io_emac1_inst_MDIO,
    output wire  hps_io_hps_io_emac1_inst_MDC,
    input wire  hps_io_hps_io_emac1_inst_RX_CTL,
    output wire  hps_io_hps_io_emac1_inst_TX_CTL,
    input wire  hps_io_hps_io_emac1_inst_RX_CLK,
    input wire  hps_io_hps_io_emac1_inst_RXD1,
    input wire  hps_io_hps_io_emac1_inst_RXD2,
    input wire  hps_io_hps_io_emac1_inst_RXD3,
    inout wire  hps_io_hps_io_sdio_inst_CMD,
    inout wire  hps_io_hps_io_sdio_inst_D0,
    inout wire  hps_io_hps_io_sdio_inst_D1,
    output wire  hps_io_hps_io_sdio_inst_CLK,
    inout wire  hps_io_hps_io_sdio_inst_D2,
    inout wire  hps_io_hps_io_sdio_inst_D3,
    inout wire  hps_io_hps_io_usb1_inst_D0,
    inout wire  hps_io_hps_io_usb1_inst_D1,
    inout wire  hps_io_hps_io_usb1_inst_D2,
    inout wire  hps_io_hps_io_usb1_inst_D3,
    inout wire  hps_io_hps_io_usb1_inst_D4,
    inout wire  hps_io_hps_io_usb1_inst_D5,
    inout wire  hps_io_hps_io_usb1_inst_D6,
    inout wire  hps_io_hps_io_usb1_inst_D7,
    input wire  hps_io_hps_io_usb1_inst_CLK,
    output wire  hps_io_hps_io_usb1_inst_STP,
    input wire  hps_io_hps_io_usb1_inst_DIR,
    input wire  hps_io_hps_io_usb1_inst_NXT,
    input wire  hps_io_hps_io_uart0_inst_RX,
    output wire  hps_io_hps_io_uart0_inst_TX,
    inout wire  hps_io_hps_io_i2c0_inst_SDA,
    inout wire  hps_io_hps_io_i2c0_inst_SCL,
    output wire [14:0] HPS_DDR3_ADDR,
    output wire [2:0] HPS_DDR3_BA,
    output wire  HPS_DDR3_CK_P,
    output wire  HPS_DDR3_CK_N,
    output wire  HPS_DDR3_CKE,
    output wire  HPS_DDR3_CS_N,
    output wire  HPS_DDR3_RAS_N,
    output wire  HPS_DDR3_CAS_N,
    output wire  HPS_DDR3_WE_N,
    output wire  HPS_DDR3_RESET_N,
    inout wire [31:0] HPS_DDR3_DQ,
    inout wire [3:0] HPS_DDR3_DQS_P,
    inout wire [3:0] HPS_DDR3_DQS_N,
    output wire  HPS_DDR3_ODT,
    output wire [3:0] HPS_DDR3_DM,
    input wire  HPS_DDR3_RZQ
);

    wire hps_reset_n;
    wire raw_reset_n = RESET_N & hps_reset_n;
    // Asynchronous assertion; release after four rising clock edges.
    (* altera_attribute = "-name SYNCHRONIZER_IDENTIFICATION FORCED" *)
    reg [3:0] reset_release = 4'b0000;
    always @(posedge FPGA_CLK1_50 or negedge raw_reset_n) begin
        if (!raw_reset_n)
            reset_release <= 4'b0000;
        else
            reset_release <= {reset_release[2:0], 1'b1};
    end
    wire system_reset_n = reset_release[3];

    wire [31:0] pwm_base_ticks;
    wire [31:0] pwm_shoulder_ticks;
    wire [31:0] pwm_elbow_ticks;
    wire [31:0] pwm_pitch_ticks;
    wire [31:0] pwm_roll_ticks;
    wire [31:0] pwm_claw_ticks;

    rx_soc u_soc (
        .clk_clk(FPGA_CLK1_50),
        .hps_fpga_reset_reset_n(hps_reset_n),
        .hps_io_hps_io_emac1_inst_TX_CLK(hps_io_hps_io_emac1_inst_TX_CLK),
        .hps_io_hps_io_emac1_inst_TXD0(hps_io_hps_io_emac1_inst_TXD0),
        .hps_io_hps_io_emac1_inst_TXD1(hps_io_hps_io_emac1_inst_TXD1),
        .hps_io_hps_io_emac1_inst_TXD2(hps_io_hps_io_emac1_inst_TXD2),
        .hps_io_hps_io_emac1_inst_TXD3(hps_io_hps_io_emac1_inst_TXD3),
        .hps_io_hps_io_emac1_inst_RXD0(hps_io_hps_io_emac1_inst_RXD0),
        .hps_io_hps_io_emac1_inst_MDIO(hps_io_hps_io_emac1_inst_MDIO),
        .hps_io_hps_io_emac1_inst_MDC(hps_io_hps_io_emac1_inst_MDC),
        .hps_io_hps_io_emac1_inst_RX_CTL(hps_io_hps_io_emac1_inst_RX_CTL),
        .hps_io_hps_io_emac1_inst_TX_CTL(hps_io_hps_io_emac1_inst_TX_CTL),
        .hps_io_hps_io_emac1_inst_RX_CLK(hps_io_hps_io_emac1_inst_RX_CLK),
        .hps_io_hps_io_emac1_inst_RXD1(hps_io_hps_io_emac1_inst_RXD1),
        .hps_io_hps_io_emac1_inst_RXD2(hps_io_hps_io_emac1_inst_RXD2),
        .hps_io_hps_io_emac1_inst_RXD3(hps_io_hps_io_emac1_inst_RXD3),
        .hps_io_hps_io_sdio_inst_CMD(hps_io_hps_io_sdio_inst_CMD),
        .hps_io_hps_io_sdio_inst_D0(hps_io_hps_io_sdio_inst_D0),
        .hps_io_hps_io_sdio_inst_D1(hps_io_hps_io_sdio_inst_D1),
        .hps_io_hps_io_sdio_inst_CLK(hps_io_hps_io_sdio_inst_CLK),
        .hps_io_hps_io_sdio_inst_D2(hps_io_hps_io_sdio_inst_D2),
        .hps_io_hps_io_sdio_inst_D3(hps_io_hps_io_sdio_inst_D3),
        .hps_io_hps_io_usb1_inst_D0(hps_io_hps_io_usb1_inst_D0),
        .hps_io_hps_io_usb1_inst_D1(hps_io_hps_io_usb1_inst_D1),
        .hps_io_hps_io_usb1_inst_D2(hps_io_hps_io_usb1_inst_D2),
        .hps_io_hps_io_usb1_inst_D3(hps_io_hps_io_usb1_inst_D3),
        .hps_io_hps_io_usb1_inst_D4(hps_io_hps_io_usb1_inst_D4),
        .hps_io_hps_io_usb1_inst_D5(hps_io_hps_io_usb1_inst_D5),
        .hps_io_hps_io_usb1_inst_D6(hps_io_hps_io_usb1_inst_D6),
        .hps_io_hps_io_usb1_inst_D7(hps_io_hps_io_usb1_inst_D7),
        .hps_io_hps_io_usb1_inst_CLK(hps_io_hps_io_usb1_inst_CLK),
        .hps_io_hps_io_usb1_inst_STP(hps_io_hps_io_usb1_inst_STP),
        .hps_io_hps_io_usb1_inst_DIR(hps_io_hps_io_usb1_inst_DIR),
        .hps_io_hps_io_usb1_inst_NXT(hps_io_hps_io_usb1_inst_NXT),
        .hps_io_hps_io_uart0_inst_RX(hps_io_hps_io_uart0_inst_RX),
        .hps_io_hps_io_uart0_inst_TX(hps_io_hps_io_uart0_inst_TX),
        .hps_io_hps_io_i2c0_inst_SDA(hps_io_hps_io_i2c0_inst_SDA),
        .hps_io_hps_io_i2c0_inst_SCL(hps_io_hps_io_i2c0_inst_SCL),
        .memory_mem_a(HPS_DDR3_ADDR),
        .memory_mem_ba(HPS_DDR3_BA),
        .memory_mem_ck(HPS_DDR3_CK_P),
        .memory_mem_ck_n(HPS_DDR3_CK_N),
        .memory_mem_cke(HPS_DDR3_CKE),
        .memory_mem_cs_n(HPS_DDR3_CS_N),
        .memory_mem_ras_n(HPS_DDR3_RAS_N),
        .memory_mem_cas_n(HPS_DDR3_CAS_N),
        .memory_mem_we_n(HPS_DDR3_WE_N),
        .memory_mem_reset_n(HPS_DDR3_RESET_N),
        .memory_mem_dq(HPS_DDR3_DQ),
        .memory_mem_dqs(HPS_DDR3_DQS_P),
        .memory_mem_dqs_n(HPS_DDR3_DQS_N),
        .memory_mem_odt(HPS_DDR3_ODT),
        .memory_mem_dm(HPS_DDR3_DM),
        .memory_oct_rzqin(HPS_DDR3_RZQ),
        .pwm_base_export(pwm_base_ticks),
        .pwm_claw_export(pwm_claw_ticks),
        .pwm_elbow_export(pwm_elbow_ticks),
        .pwm_pitch_export(pwm_pitch_ticks),
        .pwm_roll_export(pwm_roll_ticks),
        .pwm_shoulder_export(pwm_shoulder_ticks),
        .reset_reset_n(system_reset_n)
    );

    servo_pwm #(.MIN_TICKS(32'd30000), .MAX_TICKS(32'd120000)) u_pwm_base (
        .clk(FPGA_CLK1_50),
        .reset_n(system_reset_n),
        .pulse_ticks(pwm_base_ticks),
        .pwm_out(SERVO_PWM[0])
    );

    servo_pwm #(.MIN_TICKS(32'd30000), .MAX_TICKS(32'd120000)) u_pwm_shoulder (
        .clk(FPGA_CLK1_50),
        .reset_n(system_reset_n),
        .pulse_ticks(pwm_shoulder_ticks),
        .pwm_out(SERVO_PWM[1])
    );

    servo_pwm #(.MIN_TICKS(32'd30000), .MAX_TICKS(32'd130000)) u_pwm_elbow (
        .clk(FPGA_CLK1_50),
        .reset_n(system_reset_n),
        .pulse_ticks(pwm_elbow_ticks),
        .pwm_out(SERVO_PWM[2])
    );

    servo_pwm #(.MIN_TICKS(32'd21000), .MAX_TICKS(32'd119000)) u_pwm_pitch (
        .clk(FPGA_CLK1_50),
        .reset_n(system_reset_n),
        .pulse_ticks(pwm_pitch_ticks),
        .pwm_out(SERVO_PWM[3])
    );

    servo_pwm #(.MIN_TICKS(32'd21000), .MAX_TICKS(32'd119000)) u_pwm_roll (
        .clk(FPGA_CLK1_50),
        .reset_n(system_reset_n),
        .pulse_ticks(pwm_roll_ticks),
        .pwm_out(SERVO_PWM[4])
    );

    servo_pwm #(.MIN_TICKS(32'd20000), .MAX_TICKS(32'd60000)) u_pwm_claw (
        .clk(FPGA_CLK1_50),
        .reset_n(system_reset_n),
        .pulse_ticks(pwm_claw_ticks),
        .pwm_out(SERVO_PWM[5])
    );

endmodule
`default_nettype wire
