module servo_pwm #(
    parameter [31:0] MIN_TICKS = 32'd30000,
    parameter [31:0] MAX_TICKS = 32'd120000
)(
    input  wire        clk,
    input  wire        reset_n,
    input  wire [31:0] pulse_ticks,
    output wire        pwm_out
);

    // 50 MHz clock:
    // 1 tick = 20 ns
    // 1,000,000 ticks = 20 ms = 50 Hz servo frame
    localparam [19:0] FRAME_LAST = 20'd999999;

    reg [19:0] frame_count;
    reg [31:0] active_ticks;

    // Accept only pulse widths within this joint's limits.
    // Zero or an invalid value disables the channel.
    wire command_valid;

    assign command_valid =
        (pulse_ticks >= MIN_TICKS) &&
        (pulse_ticks <= MAX_TICKS);

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            frame_count <= FRAME_LAST;
            active_ticks <= 32'd0;
        end else begin
            if (frame_count == FRAME_LAST) begin
                frame_count <= 20'd0;

                // Apply changes only at the start of a frame.
                // This prevents changes from cutting a pulse short
                // or creating an extra pulse within the same frame.
                if (command_valid)
                    active_ticks <= pulse_ticks;
                else
                    active_ticks <= 32'd0;
            end else begin
                frame_count <= frame_count + 20'd1;
            end
        end
    end

    assign pwm_out =
        reset_n &&
        (active_ticks != 32'd0) &&
        ({12'd0, frame_count} < active_ticks);

endmodule