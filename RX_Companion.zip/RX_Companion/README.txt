DE10-Nano RX reproduction companion - 27 October 2026
Read the PDF first. This is not a complete bootable SD-card image.
Quartus sources are copied from the tested RX_Arm_Fresh project.
Generate rx_soc HDL in Platform Designer 25.1 before compiling the QPF.
The RBF is the existing build used in the recorded tests; verify its hash.
The legacy receiver includes the manual-console change consolidated into source.
start_rx.py is the equivalent launcher reconstructed from the recorded commands.
No private configuration, passwords, tokens or Wi-Fi credentials are included.
Create configs from examples. Replace all placeholders. Do not use example UIDs.
The optional ESP32 router's firmware and the original Angstrom SD image are not included.
Old compiled IP is not bundled; regenerate it with the matching Quartus version.
This package does not implement the transmitter board.
