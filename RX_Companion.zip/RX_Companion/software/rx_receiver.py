#!/usr/bin/env python3
"""RX bring-up and Firebase SSE receiver. Python 3.8+, requests.
Never use hardware modes before the matching FPGA image and LW bridge are verified.
Network loss holds the last PWM targets. Normal process exit disables PWM.
"""
import argparse
import contextlib
import fcntl
import json
import math
import mmap
import os
import struct
import sys
import time
from urllib.parse import urlparse

JOINTS = ('base', 'shoulder', 'elbow', 'pitch', 'roll', 'claw')
LIMITS = ((30000,120000), (30000,120000), (30000,130000),
          (21000,119000), (21000,119000), (20000,60000))
BASE = 0xFF200000
OFFSETS = tuple(i * 0x10 for i in range(6))


def ticks_for(index, angle):
    if isinstance(angle, bool) or not isinstance(angle, (int, float)):
        raise ValueError('angle must be numeric')
    if not math.isfinite(angle) or not 0 <= angle <= 180:
        raise ValueError('angle outside 0..180')
    lo, hi = LIMITS[index]
    return int(round(lo + (hi - lo) * angle / 180.0))


def decode_command(value, now_ms, max_age_ms=2000):
    if not isinstance(value, dict):
        raise ValueError('command is not an object')
    seq = value.get('seq')
    sent = value.get('sent_ms')
    if isinstance(seq, bool) or not isinstance(seq, int) or seq < 0:
        raise ValueError('invalid sequence')
    if isinstance(sent, bool) or not isinstance(sent, (int,float)) or not math.isfinite(sent):
        raise ValueError('invalid timestamp')
    age = now_ms - sent
    if age < -250 or age > max_age_ms:
        raise ValueError('stale command or clocks not synchronized')
    angles, enable = value.get('angles'), value.get('enable')
    if not isinstance(angles, dict) or not isinstance(enable, dict):
        raise ValueError('missing angles/enable objects')
    result = []
    for i, joint in enumerate(JOINTS):
        if type(enable.get(joint)) is not bool:
            raise ValueError('enable values must be booleans')
        tick = ticks_for(i, angles.get(joint))
        result.append(tick if enable[joint] else 0)
    return seq, age, result


def apply_event(state, kind, envelope):
    """Apply Firebase put/patch, including nested and multipath updates."""
    if not isinstance(envelope, dict) or not isinstance(envelope.get('path'), str):
        raise ValueError('malformed SSE event')
    def put(root, path, value):
        parts = [p for p in path.split('/') if p]
        if not parts:
            return value
        if not isinstance(root, dict):
            root = {}
        node = root
        for p in parts[:-1]:
            if not isinstance(node.get(p), dict):
                node[p] = {}
            node = node[p]
        if value is None:
            node.pop(parts[-1], None)
        else:
            node[parts[-1]] = value
        return root
    path, value = envelope['path'], envelope.get('data')
    if kind == 'put':
        return put(state, path, value)
    if kind == 'patch' and isinstance(value, dict):
        for key, v in value.items():
            state = put(state, path.rstrip('/') + '/' + key, v)
        return state
    raise ValueError('unsupported SSE update')


class Registers:
    def __init__(self):
        self.lock = open('/tmp/rx_arm_mmio.lock', 'a')
        fcntl.flock(self.lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        fd = os.open('/dev/mem', os.O_RDWR | os.O_SYNC)
        try:
            self.mem = mmap.mmap(fd, 4096, flags=mmap.MAP_SHARED,
                                 prot=mmap.PROT_READ | mmap.PROT_WRITE, offset=BASE)
        finally:
            os.close(fd)

    def read(self):
        return [struct.unpack_from('<I', self.mem, o)[0] for o in OFFSETS]

    def write(self, values):
        if len(values) != 6:
            raise ValueError('six values required')
        for i, v in enumerate(values):
            if type(v) is not int or (v != 0 and not LIMITS[i][0] <= v <= LIMITS[i][1]):
                raise ValueError('invalid pulse count')
        for off, value in zip(OFFSETS, values):
            struct.pack_into('<I', self.mem, off, value)
        if self.read() != list(values):
            raise RuntimeError('PIO readback mismatch; stop and check FPGA/bridge')

    def close(self):
        self.mem.close()
        self.lock.close()


def load_config(path):
    with open(path) as f:
        c = json.load(f)
    u = urlparse(c['database_url'])
    if u.scheme != 'https' or not u.hostname or not u.hostname.endswith(('.firebasedatabase.app','.firebaseio.com')):
        raise ValueError('use the HTTPS Realtime Database URL')
    if u.query or u.fragment or u.username or u.path not in ('', '/'):
        raise ValueError('database_url must be the database root URL')
    for k in ('api_key', 'email', 'password'):
        if not c.get(k):
            raise ValueError('missing configuration: '+k)
    return c


def login(session, c):
    r = session.post('https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword',
                     params={'key':c['api_key']}, json={'email':c['email'],
                     'password':c['password'],'returnSecureToken':True}, timeout=(10,20))
    if r.status_code != 200:
        raise RuntimeError('Firebase sign-in failed (HTTP %d)' % r.status_code)
    d = r.json()
    return d['idToken'], time.monotonic() + min(3000, int(d['expiresIn']) - 120)


def event_stream(response):
    kind, data = None, []
    # Small chunks avoid buffering small control messages waiting for 512 bytes.
    for line in response.iter_lines(chunk_size=1, decode_unicode=True):
        if not line:
            if kind:
                yield kind, '\n'.join(data)
            kind, data = None, []
        elif line.startswith('event:'):
            kind = line[6:].strip()
        elif line.startswith('data:'):
            data.append(line[5:].lstrip())


def listen(args, c):
    import requests
    regs = Registers() if args.hardware else None
    last_seq, last_log, delay = -1, 0.0, 1
    url = c['database_url'].rstrip('/') + '/rx_arm/command.json'
    try:
        if regs:
            regs.write([0]*6)
        print('Listening: '+('HARDWARE' if regs else 'DRY RUN')+
              '; disconnect policy=hold last target; exit policy=disable', flush=True)
        with requests.Session() as session:
            while True:
                try:
                    token, renew_at = login(session, c)
                    state = None
                    with session.get(url, params={'auth':token}, headers={'Accept':'text/event-stream'},
                                     stream=True, timeout=(10,65)) as response:
                        if response.status_code != 200:
                            raise RuntimeError('Database stream HTTP %d' % response.status_code)
                        response.encoding = 'utf-8'
                        delay = 1
                        for kind, payload in event_stream(response):
                            if time.monotonic() >= renew_at:
                                break
                            if kind in ('cancel','auth_revoked'):
                                raise RuntimeError('Firebase stream '+kind)
                            if kind not in ('put','patch'):
                                continue
                            try:
                                state = apply_event(state, kind, json.loads(payload))
                                seq, age, ticks = decode_command(state, time.time()*1000)
                            except (ValueError, TypeError, KeyError) as e:
                                if time.monotonic()-last_log >= 1:
                                    print('Rejected: '+str(e), flush=True); last_log=time.monotonic()
                                continue
                            if seq <= last_seq:
                                continue
                            if regs:
                                regs.write(ticks)
                            last_seq = seq
                            if time.monotonic()-last_log >= 1:
                                print('seq=%d age_ms=%.1f ticks=%s' % (seq, age, ticks), flush=True)
                                last_log = time.monotonic()
                except (requests.RequestException, RuntimeError) as e:
                    # Never print requests exception text: it can include the auth query token.
                    if isinstance(e, RuntimeError) and 'PIO readback' in str(e):
                        raise
                    label = str(e) if isinstance(e, RuntimeError) else type(e).__name__
                    print('Connection issue: %s; holding targets; retry in %ds' % (label,delay), flush=True)
                    time.sleep(delay); delay = min(10, delay*2)
    finally:
        if regs:
            try: regs.write([0]*6)
            finally: regs.close()


def send(args, c):
    """Laptop test source for RX acceptance; not the future TX-board program."""
    import requests
    if args.joint and args.angle is None:
        raise ValueError('--joint requires --angle')
    if args.joint:
        ticks_for(JOINTS.index(args.joint), args.angle)
    if args.seconds <= 0 or args.seconds > 60:
        raise ValueError('--seconds must be in (0,60]')
    with requests.Session() as s:
        token, _ = login(s, c)
        url = c['database_url'].rstrip('/') + '/rx_arm/command.json'
        end = time.monotonic()+args.seconds
        sequence = int(time.time()*1000000)
        while time.monotonic() < end:
            sequence += 1
            command = {'seq':sequence, 'sent_ms':int(time.time()*1000),
                       'angles':{j:args.angle if j==args.joint else 0 for j in JOINTS},
                       'enable':{j:j==args.joint for j in JOINTS}}
            r=s.put(url, params={'auth':token}, json=command, timeout=(10,20))
            if r.status_code != 200:
                raise RuntimeError('Test write failed (HTTP %d)' % r.status_code)
            time.sleep(0.1)
        print('Test source stopped; RX retains the last enabled target until disabled or stopped.')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    sub=p.add_subparsers(dest='mode', required=True)
    l=sub.add_parser('listen'); l.add_argument('--config',required=True); l.add_argument('--hardware',action='store_true')
    s=sub.add_parser('send'); s.add_argument('--config',required=True); s.add_argument('--joint',choices=JOINTS)
    s.add_argument('--angle',type=float); s.add_argument('--seconds',type=float,default=3)
    sub.add_parser('inspect')
    sub.add_parser('disable')
    t=sub.add_parser('local-test');t.add_argument('--joint',choices=JOINTS,required=True)
    t.add_argument('--angle',type=float,required=True);t.add_argument('--seconds',type=float,default=3)
    args=p.parse_args()
    if args.mode in ('listen','send'):
        c=load_config(args.config)
        return listen(args,c) if args.mode=='listen' else send(args,c)
    if args.mode=='local-test' and not 0 < args.seconds <= 30:
        raise ValueError('test duration must be in (0,30]')
    with contextlib.closing(Registers()) as regs:
        if args.mode=='inspect':
            print(dict(zip(JOINTS,regs.read())))
        elif args.mode=='disable':
            regs.write([0]*6);print('All PWM registers zero.')
        else:
            values=[0]*6;values[JOINTS.index(args.joint)]=ticks_for(JOINTS.index(args.joint),args.angle)
            try:
                regs.write([0]*6);regs.write(values)
                print('PIO readback:',regs.read(),flush=True)
                time.sleep(args.seconds)
            finally:
                regs.write([0]*6)

if __name__=='__main__':
    try: main()
    except KeyboardInterrupt: pass
    except Exception as e:
        # Do not expose credentials through HTTP-library exceptions.
        print('Stopped: '+(str(e) if isinstance(e,(ValueError,RuntimeError,OSError)) else type(e).__name__),file=sys.stderr)
        sys.exit(1)
