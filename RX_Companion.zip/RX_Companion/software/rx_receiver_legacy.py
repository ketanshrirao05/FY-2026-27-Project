#!/usr/bin/env python
"""Legacy RX receiver. Python 2.7/3 and curl; no third-party Python modules.
Never use hardware modes before the matching FPGA image and LW bridge are verified.
Network loss holds the last PWM targets. Normal process exit disables PWM.
"""
from __future__ import print_function
import argparse
import contextlib
import fcntl
import json
import math
import mmap
import os
import struct
import sys
import time
import subprocess
import select
import signal
try:
    from urllib.parse import urlparse, urlencode
except ImportError:
    from urlparse import urlparse
    from urllib import urlencode
try:
    INTEGER = (int, long)
    STRING = (basestring,)
except NameError:
    INTEGER = (int,)
    STRING = (str,)
NUMBER = INTEGER + (float,)
def finite(v):
    return not math.isnan(v) and not math.isinf(v)
def clock():
    return os.times()[4]
def log(message):
    print(message)
    sys.stdout.flush()


JOINTS = ('base', 'shoulder', 'elbow', 'pitch', 'roll', 'claw')
LIMITS = ((30000,120000), (30000,120000), (30000,130000),
          (21000,119000), (21000,119000), (20000,60000))
BASE = 0xFF200000
OFFSETS = tuple(i * 0x10 for i in range(6))


def ticks_for(index, angle):
    if isinstance(angle, bool) or not isinstance(angle, NUMBER):
        raise ValueError('angle must be numeric')
    if not finite(angle) or not 0 <= angle <= 180:
        raise ValueError('angle outside 0..180')
    lo, hi = LIMITS[index]
    return int(round(lo + (hi - lo) * angle / 180.0))


def decode_command(value, now_ms, max_age_ms=2000):
    if not isinstance(value, dict):
        raise ValueError('command is not an object')
    seq = value.get('seq')
    sent = value.get('sent_ms')
    if isinstance(seq, bool) or not isinstance(seq, INTEGER) or seq < 0:
        raise ValueError('invalid sequence')
    if isinstance(sent, bool) or not isinstance(sent, NUMBER) or not finite(sent):
        raise ValueError('invalid timestamp')
    age = now_ms - sent
    if age < -250 or age > max_age_ms:
        raise ValueError('stale command or clocks not synchronized')
    angles, enable = value.get('angles'), value.get('enable')
    if not isinstance(angles, dict) or not isinstance(enable, dict):
        raise ValueError('missing angles/enable objects')
    result = []
    for i, joint in enumerate(JOINTS):
        if type(enable.get(joint)) is not bool:
            raise ValueError('enable values must be booleans')
        tick = ticks_for(i, angles.get(joint))
        result.append(tick if enable[joint] else 0)
    return seq, age, result


def apply_event(state, kind, envelope):
    """Apply Firebase put/patch, including nested and multipath updates."""
    if not isinstance(envelope, dict) or not isinstance(envelope.get('path'), STRING):
        raise ValueError('malformed SSE event')
    def put(root, path, value):
        parts = [p for p in path.split('/') if p]
        if not parts:
            return value
        if not isinstance(root, dict):
            root = {}
        node = root
        for p in parts[:-1]:
            if not isinstance(node.get(p), dict):
                node[p] = {}
            node = node[p]
        if value is None:
            node.pop(parts[-1], None)
        else:
            node[parts[-1]] = value
        return root
    path, value = envelope['path'], envelope.get('data')
    if kind == 'put':
        return put(state, path, value)
    if kind == 'patch' and isinstance(value, dict):
        for key, v in value.items():
            state = put(state, path.rstrip('/') + '/' + key, v)
        return state
    raise ValueError('unsupported SSE update')


class Registers:
    def __init__(self):
        self.lock = open('/tmp/rx_arm_mmio.lock', 'a')
        fcntl.flock(self.lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        fd = os.open('/dev/mem', os.O_RDWR | os.O_SYNC)
        try:
            self.mem = mmap.mmap(fd, 4096, flags=mmap.MAP_SHARED,
                                 prot=mmap.PROT_READ | mmap.PROT_WRITE, offset=BASE)
        finally:
            os.close(fd)

    def read(self):
        return [struct.unpack_from('<I', self.mem, o)[0] for o in OFFSETS]

    def write(self, values):
        if len(values) != 6:
            raise ValueError('six values required')
        for i, v in enumerate(values):
            if type(v) is not int or (v != 0 and not LIMITS[i][0] <= v <= LIMITS[i][1]):
                raise ValueError('invalid pulse count')
        for off, value in zip(OFFSETS, values):
            struct.pack_into('<I', self.mem, off, value)
        if self.read() != list(values):
            raise RuntimeError('PIO readback mismatch; stop and check FPGA/bridge')

    def close(self):
        self.mem.close()
        self.lock.close()


def load_config(path):
    with open(path) as f:
        c = json.load(f)
    u = urlparse(c['database_url'])
    if u.scheme != 'https' or not u.hostname or not u.hostname.endswith(('.firebasedatabase.app','.firebaseio.com')):
        raise ValueError('use the HTTPS Realtime Database URL')
    if u.query or u.fragment or u.username or u.path not in ('', '/'):
        raise ValueError('database_url must be the database root URL')
    for k in ('api_key', 'email', 'password'):
        if not c.get(k):
            raise ValueError('missing configuration: '+k)
    return c



def curl_quote(value):
    return '"' + value.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n').replace('\r', '\\r') + '"'


def start_curl(url, payload=None, stream=False):
    # Secrets travel over stdin, never command arguments or diagnostic output.
    config = ['url = ' + curl_quote(url), 'silent', 'fail',
              'connect-timeout = 10', 'max-time = ' + ('3000' if stream else '30')]
    if stream:
        config += ['no-buffer', 'header = "Accept: text/event-stream"']
    else:
        config += ['header = "Content-Type: application/json"',
                   'data = ' + curl_quote(json.dumps(payload))]
    null = open(os.devnull, 'wb')
    try:
        p = subprocess.Popen(['curl', '--config', '-'], stdin=subprocess.PIPE,
                             stdout=subprocess.PIPE, stderr=null, bufsize=0)
    finally:
        null.close()
    p.stdin.write(('\n'.join(config) + '\n').encode('utf-8'))
    p.stdin.close()
    p.stdin = None
    return p


def stop_curl(p):
    if p.poll() is None:
        p.terminate()
    p.wait()
    p.stdout.close()


def login(c):
    url = 'https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?' + urlencode({'key': c['api_key']})
    p = start_curl(url, {'email': c['email'], 'password': c['password'], 'returnSecureToken': True})
    try:
        data, _ = p.communicate()
        if p.returncode:
            raise RuntimeError('Firebase sign-in: curl exit %d' % p.returncode)
        result = json.loads(data.decode('utf-8'))
        return result['idToken']
    finally:
        stop_curl(p)


def events(p):
    pending = b''
    kind, data = None, []
    last_byte = clock()
    while True:
        ready, _, _ = select.select([p.stdout], [], [], 1)
        if not ready:
            if clock() - last_byte > 70:
                raise RuntimeError('Stream idle timeout')
            continue
        chunk = os.read(p.stdout.fileno(), 4096)
        if not chunk:
            code = p.wait()
            raise RuntimeError('Database stream ended: curl exit %d' % code)
        last_byte = clock()
        pending += chunk
        if len(pending) > 262144:
            raise RuntimeError('Stream line too large')
        while b'\n' in pending:
            line, pending = pending.split(b'\n', 1)
            line = line.rstrip(b'\r').decode('utf-8')
            if not line:
                if kind:
                    yield kind, '\n'.join(data)
                kind, data = None, []
            elif line.startswith('event:'):
                kind = line[6:].strip()
            elif line.startswith('data:'):
                data.append(line[5:].lstrip())
                if sum(len(x) for x in data) > 262144:
                    raise RuntimeError('Stream event too large')


def listen(args, c):
    regs = Registers() if args.hardware else None
    last_seq, last_log, delay = -1, 0, 1
    last_ticks = None
    try:
        if regs:
            regs.write([0]*6)
        log('Listening: %s; disconnect policy=hold last target; exit policy=disable' %
            ('HARDWARE' if regs else 'DRY RUN'))
        if args.manual_console:
            log('MANUAL CONSOLE: stored targets accepted, including after reconnect; timestamp/sequence checks bypassed')
        while True:
            p = None
            try:
                token = login(c)
                url = c['database_url'].rstrip('/') + '/rx_arm/command.json?' + urlencode({'auth':token})
                p = start_curl(url, stream=True)
                state = None
                for kind, payload in events(p):
                    if kind in ('cancel', 'auth_revoked'):
                        raise RuntimeError('Firebase stream ' + kind)
                    if kind not in ('put', 'patch'):
                        continue
                    delay = 1
                    try:
                        state = apply_event(state, kind, json.loads(payload))
                        candidate = state
                        if args.manual_console and isinstance(state, dict):
                            candidate = dict(state)
                            candidate['seq'] = 0
                            candidate['sent_ms'] = time.time()*1000
                        seq, age, ticks = decode_command(candidate, time.time()*1000)
                    except (ValueError, TypeError, KeyError, OverflowError):
                        if clock()-last_log >= 1:
                            log('Rejected: invalid/stale command; check timestamps and schema')
                            last_log = clock()
                        continue
                    if args.manual_console:
                        if ticks == last_ticks:
                            continue
                    elif seq <= last_seq:
                        continue
                    if regs:
                        regs.write(ticks)
                    last_seq = seq
                    last_ticks = ticks
                    if clock()-last_log >= 1:
                        log(('manual ticks=%s' % ticks) if args.manual_console else ('seq=%d age_ms=%.1f ticks=%s' % (seq, age, ticks)))
                        last_log = clock()
            except RuntimeError as e:
                if 'PIO readback' in str(e):
                    raise
                log('Connection issue: %s; holding targets; retry in %ds' % (e, delay))
            finally:
                if p is not None:
                    stop_curl(p)
            time.sleep(delay)
            delay = min(10, delay*2)
    finally:
        if regs:
            try:
                regs.write([0]*6)
            finally:
                regs.close()


def interrupted(signum, frame):
    raise KeyboardInterrupt()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='mode')
    l = sub.add_parser('listen')
    l.add_argument('--config', required=True)
    l.add_argument('--hardware', action='store_true')
    l.add_argument('--manual-console', action='store_true', help='Accept stored console targets without timestamp/sequence freshness checks')
    sub.add_parser('inspect')
    sub.add_parser('disable')
    args = p.parse_args()
    signal.signal(signal.SIGTERM, interrupted)
    if args.mode == 'listen':
        return listen(args, load_config(args.config))
    if args.mode not in ('inspect', 'disable'):
        p.error('select listen, inspect, or disable')
    with contextlib.closing(Registers()) as regs:
        if args.mode == 'inspect':
            log(str(dict(zip(JOINTS, regs.read()))))
        else:
            regs.write([0]*6)
            log('All PWM registers zero.')


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        pass
    except Exception as e:
        # Never print arbitrary exception details that might include credentials.
        log('Stopped: ' + type(e).__name__)
        sys.exit(1)
