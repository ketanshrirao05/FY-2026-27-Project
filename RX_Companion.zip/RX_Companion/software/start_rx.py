#!/usr/bin/env python
import os
import sys
os.chdir("/home/root")
os.execv(sys.executable, [sys.executable, "-u",
    "/home/root/rx_receiver_legacy.py", "listen",
    "--config", "/home/root/rx_config.json",
    "--hardware", "--manual-console"])
