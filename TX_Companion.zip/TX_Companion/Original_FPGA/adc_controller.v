module adc_controller (
    input  wire        clk,        // 50 MHz Clock
    input  wire        reset_n,    // Active-low reset
    output reg         adc_cs_n,   // ADC_CONVST
    output reg         adc_saddr,  // ADC_SDI
    output reg         adc_sclk,   // ADC_SCK
    input  wire        adc_sdat,   // ADC_SDO
    output reg  [11:0] ch0_data,   // Joystick 1 X
    output reg  [11:0] ch1_data,   // Joystick 1 Y
    output reg  [11:0] ch2_data,   // Joystick 2 X
    output reg  [11:0] ch3_data    // Joystick 2 Y
);

    // 5 MHz SPI tick generator (50 MHz / 10 = 200 ns period)
    reg [3:0] clk_div;
    reg       tick;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            clk_div <= 4'd0;
            tick    <= 1'b0;
        end else begin
            if (clk_div == 4'd9) begin
                clk_div <= 4'd0;
                tick    <= 1'b1;
            end else begin
                clk_div <= clk_div + 1'b1;
                tick    <= 1'b0;
            end
        end
    end

    // LTC2308 6-bit channel commands: {S/D, O/S, S1, S0, UNI, SLP}
    // Single-ended, unipolar: CH0=100010, CH1=110010, CH2=100110, CH3=110110
    reg [5:0] cmd_table [0:3];
    initial begin
        cmd_table[0] = 6'b100010; // CH0
        cmd_table[1] = 6'b110010; // CH1
        cmd_table[2] = 6'b100110; // CH2
        cmd_table[3] = 6'b110110; // CH3
    end

    reg [6:0]  step;
    reg [1:0]  cur_ch;
    reg [1:0]  latched_ch;
    reg [5:0]  cmd_shift;
    reg [11:0] rx_shift;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            adc_cs_n   <= 1'b0;
            adc_sclk   <= 1'b0;
            adc_saddr  <= 1'b0;
            ch0_data   <= 12'd2048;
            ch1_data   <= 12'd2048;
            ch2_data   <= 12'd2048;
            ch3_data   <= 12'd2048;
            step       <= 7'd0;
            cur_ch     <= 2'd0;
            latched_ch <= 2'd0;
            cmd_shift  <= 6'd0;
            rx_shift   <= 12'd0;
        end else if (tick) begin
            case (step)
                // 1. Send CONVST pulse (active high for 1.0 us)
                7'd0: begin
                    adc_cs_n  <= 1'b1;
                    adc_sclk  <= 1'b0;
                    cmd_shift <= cmd_table[cur_ch];
                    step      <= step + 1'b1;
                end
                7'd1, 7'd2, 7'd3: step <= step + 1'b1;
                7'd4: begin
                    adc_cs_n <= 1'b0;
                    step     <= step + 1'b1;
                end

                // 2. Wait t_CONV (1.6 us)
                7'd5, 7'd6, 7'd7, 7'd8, 7'd9, 7'd10, 7'd11, 7'd12: step <= step + 1'b1;

                // 3. Shift 12 bits: transmit configuration command and read channel sample
                7'd13, 7'd15, 7'd17, 7'd19, 7'd21, 7'd23,
                7'd25, 7'd27, 7'd29, 7'd31, 7'd33, 7'd35: begin
                    adc_sclk  <= 1'b0;
                    adc_saddr <= cmd_shift[5];
                    cmd_shift <= {cmd_shift[4:0], 1'b0};
                    step      <= step + 1'b1;
                end

                7'd14, 7'd16, 7'd18, 7'd20, 7'd22, 7'd24,
                7'd26, 7'd28, 7'd30, 7'd32, 7'd34, 7'd36: begin
                    adc_sclk <= 1'b1;
                    rx_shift <= {rx_shift[10:0], adc_sdat};
                    step     <= step + 1'b1;
                end

                // 4. Latch 12-bit value into the respective register
                7'd37: begin
                    adc_sclk <= 1'b0;
                    case (latched_ch)
                        2'd0: ch0_data <= rx_shift;
                        2'd1: ch1_data <= rx_shift;
                        2'd2: ch2_data <= rx_shift;
                        2'd3: ch3_data <= rx_shift;
                    endcase
                    latched_ch <= cur_ch;
                    cur_ch     <= cur_ch + 1'b1;
                    step       <= 7'd0;
                end

                default: step <= 7'd0;
            endcase
        end
    end

endmodule