// Top-level module for the DE10-Nano 2-Joystick -> 6-DOF Robotic Arm Teleop project
module de10nano_teleop_top (
    input  wire        FPGA_CLK1_50,

    // HPS DDR3
    output wire [14:0] HPS_DDR3_ADDR,
    output wire [2:0]  HPS_DDR3_BA,
    output wire        HPS_DDR3_CK_P,
    output wire        HPS_DDR3_CK_N,
    output wire        HPS_DDR3_CKE,
    output wire        HPS_DDR3_CS_N,
    output wire        HPS_DDR3_RAS_N,
    output wire        HPS_DDR3_CAS_N,
    output wire        HPS_DDR3_WE_N,
    output wire        HPS_DDR3_RESET_N,
    inout  wire [31:0] HPS_DDR3_DQ,
    inout  wire [3:0]  HPS_DDR3_DQS_P,
    inout  wire [3:0]  HPS_DDR3_DQS_N,
    output wire [3:0]  HPS_DDR3_ODT,
    output wire [3:0]  HPS_DDR3_DM,
    input  wire        HPS_DDR3_RZQ,

    // HPS Ethernet (EMAC0 / RGMII)
    output wire        HPS_ENET_GTX_CLK,
    output wire [3:0]  HPS_ENET_TX_DATA,
    input  wire [3:0]  HPS_ENET_RX_DATA,
    inout  wire        HPS_ENET_MDIO,
    output wire        HPS_ENET_MDC,
    input  wire        HPS_ENET_RX_DV,
    output wire        HPS_ENET_TX_EN,
    input  wire        HPS_ENET_RX_CLK,

    // HPS SD Card (SDIO, 4-bit)
    inout  wire        HPS_SD_CMD,
    inout  wire [3:0]  HPS_SD_DATA,
    output wire        HPS_SD_CLK,

    // HPS UART0
    input  wire        HPS_UART_RX,
    output wire        HPS_UART_TX,

    // Onboard LTC2308 ADC
    output wire        ADC_CS_N,
    output wire        ADC_SADDR,
    output wire        ADC_SCLK,
    input  wire        ADC_SDAT,

    // Joystick Pushbuttons (active-low with pull-ups)
    input  wire        JS1_SW,
    input  wire        JS2_SW,

    // Servo PWM Outputs -> GPIO 1 header [0: Base, 1: Shoulder, 2: Elbow, 3: Pitch, 4: Roll, 5: Gripper]
    output wire [5:0]  GPIO_1
);

    // Internal Wires
    wire [11:0] js1_x, js1_y, js2_x, js2_y;
    wire        js1_sw_clean, js2_sw_clean;
    wire [31:0] pwm_duty [0:5];

    // 1. Platform Designer System: HPS (Memory + HPS IO) + 11 PIOs
    soc_system u0 (
        .clk_clk                             (FPGA_CLK1_50),
        .reset_reset_n                       (1'b1),
        .h2f_reset_reset_n                   (),

        // DDR3 SDRAM
        .memory_mem_a                        (HPS_DDR3_ADDR),
        .memory_mem_ba                       (HPS_DDR3_BA),
        .memory_mem_ck                       (HPS_DDR3_CK_P),
        .memory_mem_ck_n                     (HPS_DDR3_CK_N),
        .memory_mem_cke                      (HPS_DDR3_CKE),
        .memory_mem_cs_n                     (HPS_DDR3_CS_N),
        .memory_mem_ras_n                    (HPS_DDR3_RAS_N),
        .memory_mem_cas_n                    (HPS_DDR3_CAS_N),
        .memory_mem_we_n                     (HPS_DDR3_WE_N),
        .memory_mem_reset_n                  (HPS_DDR3_RESET_N),
        .memory_mem_dq                       (HPS_DDR3_DQ),
        .memory_mem_dqs                      (HPS_DDR3_DQS_P),
        .memory_mem_dqs_n                    (HPS_DDR3_DQS_N),
        .memory_mem_odt                      (HPS_DDR3_ODT),
        .memory_mem_dm                       (HPS_DDR3_DM),
        .memory_oct_rzqin                    (HPS_DDR3_RZQ),

        // Ethernet
        .hps_io_hps_io_emac0_inst_TX_CLK     (HPS_ENET_GTX_CLK),
        .hps_io_hps_io_emac0_inst_TXD0       (HPS_ENET_TX_DATA[0]),
        .hps_io_hps_io_emac0_inst_TXD1       (HPS_ENET_TX_DATA[1]),
        .hps_io_hps_io_emac0_inst_TXD2       (HPS_ENET_TX_DATA[2]),
        .hps_io_hps_io_emac0_inst_TXD3       (HPS_ENET_TX_DATA[3]),
        .hps_io_hps_io_emac0_inst_RXD0       (HPS_ENET_RX_DATA[0]),
        .hps_io_hps_io_emac0_inst_MDIO       (HPS_ENET_MDIO),
        .hps_io_hps_io_emac0_inst_MDC        (HPS_ENET_MDC),
        .hps_io_hps_io_emac0_inst_RX_CTL     (HPS_ENET_RX_DV),
        .hps_io_hps_io_emac0_inst_TX_CTL     (HPS_ENET_TX_EN),
        .hps_io_hps_io_emac0_inst_RX_CLK     (HPS_ENET_RX_CLK),
        .hps_io_hps_io_emac0_inst_RXD1       (HPS_ENET_RX_DATA[1]),
        .hps_io_hps_io_emac0_inst_RXD2       (HPS_ENET_RX_DATA[2]),
        .hps_io_hps_io_emac0_inst_RXD3       (HPS_ENET_RX_DATA[3]),

        // SD Card
        .hps_io_hps_io_sdio_inst_CMD         (HPS_SD_CMD),
        .hps_io_hps_io_sdio_inst_D0          (HPS_SD_DATA[0]),
        .hps_io_hps_io_sdio_inst_D1          (HPS_SD_DATA[1]),
        .hps_io_hps_io_sdio_inst_CLK         (HPS_SD_CLK),
        .hps_io_hps_io_sdio_inst_D2          (HPS_SD_DATA[2]),
        .hps_io_hps_io_sdio_inst_D3          (HPS_SD_DATA[3]),

        // UART0
        .hps_io_hps_io_uart0_inst_RX         (HPS_UART_RX),
        .hps_io_hps_io_uart0_inst_TX         (HPS_UART_TX),

        // Joystick Inputs (Inputs to HPS)
        .pio_buttons_external_connection_export ({js2_sw_clean, js1_sw_clean}),
        .pio_js1_x_external_connection_export   (js1_x),
        .pio_js1_y_external_connection_export   (js1_y),
        .pio_js2_x_external_connection_export   (js2_x),
        .pio_js2_y_external_connection_export   (js2_y),

        // Servo PWM Outputs (Outputs from HPS)
        .pio_pwm0_external_connection_export    (pwm_duty[0]),
        .pio_pwm1_external_connection_export    (pwm_duty[1]),
        .pio_pwm2_external_connection_export    (pwm_duty[2]),
        .pio_pwm3_external_connection_export    (pwm_duty[3]),
        .pio_pwm4_external_connection_export    (pwm_duty[4]),
        .pio_pwm5_external_connection_export    (pwm_duty[5])
    );

    // 2. ADC Controller: Reads LTC2308 and feeds joystick channels
    adc_controller u_adc (
        .clk      (FPGA_CLK1_50),
        .reset_n  (1'b1),
        .adc_cs_n (ADC_CS_N),
        .adc_saddr(ADC_SADDR),
        .adc_sclk (ADC_SCLK),
        .adc_sdat (ADC_SDAT),
        .ch0_data (js1_x),
        .ch1_data (js1_y),
        .ch2_data (js2_x),
        .ch3_data (js2_y)
    );

    // 3. Debounce Blocks for Joystick Switches
    debounce u_db1 (
        .clk       (FPGA_CLK1_50),
        .noisy_in  (JS1_SW),
        .clean_out (js1_sw_clean)
    );

    debounce u_db2 (
        .clk       (FPGA_CLK1_50),
        .noisy_in  (JS2_SW),
        .clean_out (js2_sw_clean)
    );

    // 4. Six PWM Generators (one per servo)
    genvar i;
    generate
        for (i = 0; i < 6; i = i + 1) begin : pwm_gen
            pwm_generator #(
                .CLK_FREQ_HZ(50_000_000)
            ) u_pwm (
                .clk                (FPGA_CLK1_50),
                .reset_n            (1'b1),
                .pulse_width_counts (pwm_duty[i]),
                .pwm_out            (GPIO_1[i])
            );
        end
    endgenerate

endmodule