module debounce #(
    parameter CLK_FREQ_HZ   = 50_000_000,
    parameter STABLE_TIME_MS = 20
)(
    input  wire clk,
    input  wire noisy_in,
    output reg  clean_out
);
    localparam integer SAMPLE_DIVIDE = CLK_FREQ_HZ / 1000;
    localparam integer STABLE_COUNT  = STABLE_TIME_MS;

    reg [$clog2(SAMPLE_DIVIDE)-1:0] sample_clk_div = 0;
    reg sample_tick = 0;
    reg [$clog2(STABLE_COUNT+1)-1:0] stable_counter = 0;
    reg sync_0, sync_1;
    reg last_sampled;

    initial clean_out = 1'b0;

    always @(posedge clk) begin
        sync_0 <= noisy_in;
        sync_1 <= sync_0;
    end

    always @(posedge clk) begin
        if (sample_clk_div == SAMPLE_DIVIDE - 1) begin
            sample_clk_div <= 0;
            sample_tick    <= 1'b1;
        end else begin
            sample_clk_div <= sample_clk_div + 1'b1;
            sample_tick    <= 1'b0;
        end
    end

    always @(posedge clk) begin
        if (sample_tick) begin
            if (sync_1 == last_sampled) begin
                if (stable_counter < STABLE_COUNT)
                    stable_counter <= stable_counter + 1'b1;
                else
                    clean_out <= ~sync_1; // Inverts active-low joystick buttons
            end else begin
                stable_counter <= 0;
            end
            last_sampled <= sync_1;
        end
    end
endmodule