module pwm_generator #(
    parameter CLK_FREQ_HZ = 50_000_000
)(
    input  wire        clk,
    input  wire        reset_n,
    input  wire [31:0] pulse_width_counts,
    output reg         pwm_out
);
    localparam FRAME_COUNTS = CLK_FREQ_HZ / 50; // 20ms period (50 Hz frame)

    reg [19:0] counter;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            counter <= 0;
            pwm_out <= 0;
        end else begin
            counter <= (counter >= FRAME_COUNTS - 1) ? 0 : counter + 1;
            pwm_out <= (counter < pulse_width_counts);
        end
    end
endmodule