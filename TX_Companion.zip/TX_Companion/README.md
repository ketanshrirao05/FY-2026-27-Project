# DE10-Nano TX companion
Read Guide_source.md or the companion PDF first.
Original_FPGA: preserved user-identified source and historical RBF.
Rebuild_FPGA: documented source corrections; not hardware-tested.
software: final TX controller and persistent libcurl transport reconstructed from PuTTY log; generic credential setup and read-only ADC diagnostic.
reference: saved Platform Designer parameters, connections, exports, historical reports and new validation results.
Private credentials and OS/bootloader images are excluded. Supply a compatible DE10-Nano Linux SD image and configured Internet gateway. Do not build a new preloader from the archived generic DDR parameters without board validation.
Use Python 2.7 on the recorded board. Python 3 syntax checks alone do not establish board runtime compatibility.
