from __future__ import print_function
import os, mmap, struct, time
fd = os.open('/dev/mem', os.O_RDWR | os.O_SYNC)
m = mmap.mmap(fd, 4096, mmap.MAP_SHARED,
              mmap.PROT_READ | mmap.PROT_WRITE, offset=0xff200000)
try:
    while True:
        values = [struct.unpack_from('<I', m, o)[0] for o in (0x60,0x70,0x80,0x90,0xa0)]
        print('JS1 X=%d Y=%d | JS2 X=%d Y=%d | buttons=%02x' % tuple(values))
        time.sleep(0.1)
except KeyboardInterrupt:
    pass
finally:
    m.close()
    os.close(fd)
