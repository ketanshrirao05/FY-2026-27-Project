from __future__ import print_function
import os
import sys
import json
import time
import mmap
import struct
import subprocess
import threading
import fcntl

JOINTS = ('base', 'shoulder', 'elbow', 'pitch', 'roll', 'claw')
AXES = ('shoulder', 'base', 'elbow', 'pitch')
OFFSETS = (0x60, 0x70, 0x80, 0x90)
SPEED = 25.0
DEADZONE = 150.0

def quote(s):
    return '"' + s.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n').replace('\r', '\\r') + '"'

def request(url, payload=None, method=None):
    cfg = [
        'url = ' + quote(url),
        'silent',
        'ipv4',
        'connect-timeout = 5',
        'max-time = 8',
        'write-out = "\\n%{http_code}"'
    ]
    if method:
        cfg.append('request = ' + quote(method))
    if payload is not None:
        cfg += [
            'header = "Content-Type: application/json"',
            'data = ' + quote(json.dumps(payload))
        ]
    p = subprocess.Popen(
        ['curl', '--config', '-'],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE
    )
    out, err = p.communicate(('\n'.join(cfg) + '\n').encode('utf-8'))
    if p.returncode:
        raise RuntimeError('curl exit %d' % p.returncode)
    body, status = out.decode('utf-8').rsplit('\n', 1)
    if int(status) != 200:
        raise RuntimeError('Firebase HTTP ' + status)
    return json.loads(body)

def velocity(raw, centre):
    d = raw - centre
    if abs(d) <= DEADZONE:
        return 0.0
    span = (3345 - centre) if d > 0 else centre
    direction = 1 if d > 0 else -1
    fraction = (abs(d) - DEADZONE) / max(1, span - DEADZONE)
    return direction * SPEED * min(1.0, fraction)

def main():
    lockfile = open('/tmp/tx_control.lock', 'a')
    fcntl.flock(lockfile, fcntl.LOCK_EX | fcntl.LOCK_NB)

    with open('/home/root/tx_config.json') as f:
        config = json.load(f)

    def login():
        result = request(
            'https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key='
            + config['api_key'],
            dict(email=config['email'], password=config['password'],
                 returnSecureToken=True)
        )
        return result['idToken']

    token = login()
    endpoint = config['database_url'].rstrip('/') + '/rx_arm/command.json?auth='
    state = request(endpoint + token)
    if not isinstance(state, dict):
        raise ValueError('Set initial RX targets in Firebase first')

    angles = state['angles']
    enables = state['enable']
    for joint in JOINTS:
        value = angles[joint]
        if isinstance(value, bool) or not isinstance(value, (int, long, float)):
            raise ValueError('Invalid angle: ' + joint)
        if not 0 <= value <= 180:
            raise ValueError('Angle outside 0..180: ' + joint)
        if type(enables[joint]) is not bool:
            raise ValueError('Invalid enable: ' + joint)

    sequence = [max(int(state.get('seq', 0)), int(time.time() * 1000000))]

    fd = os.open('/dev/mem', os.O_RDWR | os.O_SYNC)
    mem = mmap.mmap(fd, 4096, mmap.MAP_SHARED,
                    mmap.PROT_READ, offset=0xFF200000)
    os.close(fd)

    def read(offset):
        return struct.unpack_from('<I', mem, offset)[0]

    raw_input('Release both sticks and switches; press Enter to calibrate: ')
    samples = []
    for n in range(100):
        samples.append([read(o) for o in OFFSETS] + [read(0xA0) & 1])
        time.sleep(.01)

    centres = [sorted(s[i] for s in samples)[50] for i in range(4)]
    if any(c < 500 or c > 2800 for c in centres):
        raise ValueError('Centre out of range; check joystick wiring')

    idle = samples[-1][4]
    if any(s[4] != idle for s in samples):
        raise ValueError('Switch changed during calibration; restart')

    print('Centres:', centres)
    print('Starting targets:', angles)
    print('Roll unchanged:', angles['roll'], 'enabled:', enables['roll'])

    if raw_input('Type START to enable the five controlled joints: ').strip() != 'START':
        mem.close()
        return

    for joint in AXES + ('claw',):
        enables[joint] = True

    mutex = threading.Lock()
    stop = threading.Event()
    connected = threading.Event()

    def publish():
        auth = token
        renewed = time.time()
        failures = 0
        while not stop.is_set():
            try:
                if time.time() - renewed > 3000 or failures:
                    auth = login()
                    renewed = time.time()
                with mutex:
                    packet = dict(
                        angles=dict(angles),
                        enable=dict(enables),
                        seq=sequence[0],
                        sent_ms=int(time.time() * 1000)
                    )
                begin = time.time()
                request(endpoint + auth, packet, 'PUT')
                failures = 0
                connected.set()
                print('Sent request_ms=%.0f angles=%s' %
                      (1000 * (time.time() - begin), packet['angles']))
                sys.stdout.flush()
                stop.wait(.02)
            except Exception as error:
                connected.clear()
                failures += 1
                print('Connection issue:', str(error))
                print('Targets paused; RX holds its last received command.')
                sys.stdout.flush()
                stop.wait(min(5, failures))

    worker = threading.Thread(target=publish)
    worker.daemon = True
    worker.start()

    previous = os.times()[4]
    candidate = idle
    stable = idle
    changed = previous

    try:
        while True:
            now = os.times()[4]
            dt = min(.05, max(0, now - previous))
            previous = now
            raw = [read(o) for o in OFFSETS]
            bit = read(0xA0) & 1

            if bit != candidate:
                candidate = bit
                changed = now

            pressed = False
            if candidate != stable and now - changed >= .05:
                stable = candidate
                pressed = stable != idle

            with mutex:
                if connected.is_set():
                    for i, joint in enumerate(AXES):
                        target = angles[joint] + velocity(raw[i], centres[i]) * dt
                        angles[joint] = round(max(0, min(180, target)), 4)
                    if pressed:
                        angles['claw'] = 0.0 if angles['claw'] >= 90 else 180.0
                sequence[0] += 1
            time.sleep(.01)

    except KeyboardInterrupt:
        print('\nStopping TX; RX retains its last received targets.')
    finally:
        stop.set()
        worker.join(18)
        mem.close()

from tx_http import request

if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print('Stopped:', str(error))
        sys.exit(1)
