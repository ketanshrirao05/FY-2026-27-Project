from __future__ import print_function
import json
import os
import getpass
import subprocess

def quote(s):
    return '"' + s.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n').replace('\r', '\\r') + '"'

def request(url, payload=None):
    cfg = [
        'url = ' + quote(url),
        'silent',
        'connect-timeout = 10',
        'max-time = 30',
        'write-out = "\\n%{http_code}"'
    ]
    if payload is not None:
        cfg += [
            'header = "Content-Type: application/json"',
            'data = ' + quote(json.dumps(payload))
        ]
    p = subprocess.Popen(
        ['curl', '--config', '-'],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE
    )
    out, err = p.communicate(('\n'.join(cfg) + '\n').encode('utf-8'))
    if p.returncode:
        raise RuntimeError('Network/TLS error; curl exit %s' % p.returncode)
    body, status = out.decode('utf-8').rsplit('\n', 1)
    return int(status), json.loads(body)

c = {}

try:
    c['database_url'] = raw_input('Firebase database URL (https://...): ').strip().rstrip('/')
    c['api_key'] = raw_input('Firebase Web API key: ').strip()
    c['email'] = raw_input('Firebase TX email: ').strip()
    c['password'] = getpass.getpass('Firebase TX account password: ')
    status, result = request(
        'https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=' + c['api_key'],
        {'email': c['email'], 'password': c['password'],
         'returnSecureToken': True}
    )
    print('Sign-in HTTP:', status)
    if status != 200:
        print('Firebase error:', result.get('error'))
        raise SystemExit(1)

    print('Writer UID:', result['localId'])
    status, command = request(
        c['database_url'] + '/rx_arm/command.json?auth=' + result['idToken']
    )
    print('Database read HTTP:', status)
    if status != 200:
        print('Database error:', command)
        raise SystemExit(1)

    os.umask(0o077)
    path = '/home/root/tx_config.json'
    with open(path, 'w') as f:
        json.dump(c, f, indent=2)
    os.chmod(path, 0o600)
    print('Saved:', path)
    print('Firebase connection OK. No commands were written.')
except Exception as e:
    print('Setup failed:', str(e))
