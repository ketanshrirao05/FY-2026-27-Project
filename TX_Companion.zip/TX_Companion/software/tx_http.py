import ctypes as C
import ctypes.util
import threading
import json

lib = C.CDLL(ctypes.util.find_library('curl'))
P = C.c_void_p
lib.curl_global_init.argtypes = [C.c_long]
lib.curl_global_init.restype = C.c_int
lib.curl_easy_init.argtypes = []
lib.curl_easy_init.restype = P
lib.curl_easy_setopt.argtypes = [P, C.c_int]
lib.curl_easy_setopt.restype = C.c_int
lib.curl_easy_getinfo.argtypes = [P, C.c_int]
lib.curl_easy_getinfo.restype = C.c_int
lib.curl_easy_perform.argtypes = [P]
lib.curl_easy_perform.restype = C.c_int
lib.curl_easy_reset.argtypes = [P]
lib.curl_easy_reset.restype = None
lib.curl_slist_append.argtypes = [P, C.c_char_p]
lib.curl_slist_append.restype = P
lib.curl_slist_free_all.argtypes = [P]
lib.curl_slist_free_all.restype = None

if lib.curl_global_init(3):
    raise RuntimeError('libcurl initialization failed')

local = threading.local()
Callback = C.CFUNCTYPE(
    C.c_size_t, P, C.c_size_t, C.c_size_t, P
)

def request(url, payload=None, method=None):
    if not hasattr(local, 'handle'):
        local.handle = lib.curl_easy_init()
        if not local.handle:
            raise RuntimeError('Cannot allocate curl handle')
    h = local.handle
    lib.curl_easy_reset(h)
    parts = []

    @Callback
    def receive(ptr, size, count, userdata):
        length = size * count
        try:
            parts.append(C.string_at(ptr, length))
            return length
        except Exception:
            return 0

    def option(key, value):
        rc = lib.curl_easy_setopt(h, key, value)
        if rc:
            raise RuntimeError('curl option %d error %d' % (key, rc))

    headers = None
    try:
        url_bytes = url.encode('utf-8')
        option(10002, C.c_char_p(url_bytes))
        option(20011, receive)

        # No signals; IPv4; timeouts; HTTP/1.1; verify TLS.
        for key, value in (
            (99, 1), (113, 1), (156, 5000), (155, 8000),
            (84, 2), (64, 1), (81, 2), (52, 0)
        ):
            option(key, C.c_long(value))

        if payload is not None:
            body = json.dumps(
                payload, separators=(',', ':')
            ).encode('utf-8')
            headers = lib.curl_slist_append(
                None, b'Content-Type: application/json'
            )
            if not headers:
                raise RuntimeError('Cannot allocate headers')
            extra = lib.curl_slist_append(headers, b'Expect:')
            if not extra:
                raise RuntimeError('Cannot allocate headers')
            headers = extra
            option(10023, P(headers))
            option(60, C.c_long(len(body)))
            option(10015, C.c_char_p(body))

        if method:
            method_bytes = method.encode('ascii')
            option(10036, C.c_char_p(method_bytes))

        rc = lib.curl_easy_perform(h)
        if rc:
            raise RuntimeError('libcurl error %d' % rc)

        status = C.c_long()
        rc = lib.curl_easy_getinfo(
            h, 0x200002, C.byref(status)
        )
        if rc:
            raise RuntimeError('Cannot read HTTP status')
        if status.value != 200:
            raise RuntimeError('Firebase HTTP %d' % status.value)
        return json.loads(b''.join(parts).decode('utf-8'))
    finally:
        # Reset options while retaining cached connections.
        lib.curl_easy_reset(h)
        if headers:
            lib.curl_slist_free_all(headers)
